<?php
//DADOS PARA CONEXAO COM O BANCO DE DADOS
$dbHost		= "localhost";
$dbName		= "sgt"; 
$dbUser		= "root";
$dbPassword	= "";
//--

// CONEXAO COM O BANCO DE DADOS
$conexao = mysql_connect($dbHost,$dbUser,$dbPassword);
mysql_select_db($dbName);
//--

// TÍTULO DAS PÁGINAS
//$titulo = "Painel de controle";
//--
?>