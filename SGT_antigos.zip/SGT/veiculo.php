<!---BY SHIELD--->
<?php 
if(!isset($_SESSION)){session_start();//echo $_SESSION['nomeUuario'];
                           }
if(empty($_SESSION['nomeUuario'])){

 header("Location: login.php?erro=aut");
}

?>
<?php
    require_once 'config/conexao.class.php';
    require_once 'config/crud.class.php';

    $con = new conexao(); // instancia classe de conxao
    $con->connect(); // abre conexao com o banco
    @$getId = $_GET['id'];  //pega id para ediçao caso exista
    if(@$getId){ //se existir recupera os dados e tras os campos preenchidos
        $consulta = mysql_query("SELECT * FROM usuario WHERE id = + $getId");
        $campo = mysql_fetch_array($consulta);
    }
    
    if(isset ($_POST['cadastrar'])){  // caso nao seja passado o id via GET cadastra 
        $servico = $_POST['ie_servico'];  //pega o elemento com o pelo NAME
			$prefixo = $_POST['nr_prefixo']; //pega o elemento com o pelo NAME 
			$fabricante = $_POST['ie_fabricante']; //pega o elemento com o pelo NAME 
			$modelo = $_POST['ds_modelo']; //pega o elemento com o pelo NAME 
			$cor = $_POST['ds_cor']; //pega o elemento com o pelo NAME 
			$anoFabricacao = $_POST['dt_anoFabricacao']; //pega o elemento com o pelo NAME 
      $anoModelo = $_POST['dt_anoModelo']; //pega o elemento com o pelo NAME 
      $chassi = $_POST['ds_chassi']; //pega o elemento com o pelo NAME 
      $placa = $_POST['ds_placa']; //pega o elemento com o pelo NAME
			$municipioVeiculo = $_POST['ds_minicipioVeiculo']; //pega o elemento com o pelo NAME
			$ufVeiculo = $_POST['sg_ufVeiculo']; //pega o elemento com o pelo NAME 
			$publicidade = $_POST['_publicidade']; //pega o elemento com o pelo NAME 
      $qtdePassageiros = $_POST['nr_qtdePassageiros']; //pega o elemento com o pelo NAME 
      $associcao = $_POST['ds_associcao'];
      $particular = $_POST['_particular']; //pega o elemento com o pelo NAME 
      $numeroProtocoloPublicidade = $_POST['nr_protocoloPublicidade'];
      $dataProtocoloPublicidade = $_POST['dt_protocoloPublicidade'];
      $linha = $_POST['ie_linha'];
        $crud = new crud('veiculo');  // instancia classe com as operaçoes crud, passando o nome da tabela como parametro
        $crud->inserir("ie_servico,nr_prefixo,ie_fabricante,ds_modelo,ds_cor,dt_anoFabricacao,ds_chassi,
        ds_placa,ds_minicipioVeiculo,sg_ufVeiculo,_publicidade,nr_qtdePassageiros,ds_associcao,_particular,
				nr_protocoloPublicidade,dt_protocoloPublicidade,ie_linha", "'$servico','$prefixo','$fabricante','$modelo',
				'$cor','$anoFabricacao','$anoModelo','$chassi','$placa','$municipioVeiculo','$ufVeiculo','$publicidade','$qtdePassageiros',
        '$associcao','$particular','$numeroProtocoloPublicidade','$dataProtocoloPublicidade','$linha'"); // utiliza a funçao INSERIR da classe crud
        header("Location: listagemVeiculo.php"); // redireciona para a listagem
    }

    if(isset ($_POST['editar'])){ // caso  seja passado o id via GET edita 
        $servico = $_POST['ie_servico'];  //pega o elemento com o pelo NAME
			$prefixo = $_POST['nr_prefixo']; //pega o elemento com o pelo NAME 
			$fabricante = $_POST['ie_fabricante']; //pega o elemento com o pelo NAME 
			$modelo = $_POST['ds_modelo']; //pega o elemento com o pelo NAME 
			$cor = $_POST['ds_cor']; //pega o elemento com o pelo NAME 
			$anoFabricacao = $_POST['dt_anoFabricacao']; //pega o elemento com o pelo NAME 
      $anoModelo = $_POST['dt_anoModelo']; //pega o elemento com o pelo NAME 
      $chassi = $_POST['ds_chassi']; //pega o elemento com o pelo NAME 
      $placa = $_POST['ds_placa']; //pega o elemento com o pelo NAME
			$municipioVeiculo = $_POST['ds_minicipioVeiculo']; //pega o elemento com o pelo NAME
			$ufVeiculo = $_POST['sg_ufVeiculo']; //pega o elemento com o pelo NAME 
			$publicidade = $_POST['_publicidade']; //pega o elemento com o pelo NAME 
      $qtdePassageiros = $_POST['nr_qtdePassageiros']; //pega o elemento com o pelo NAME 
      $associcao = $_POST['ds_associcao'];
      $particular = $_POST['_particular']; //pega o elemento com o pelo NAME 
      $numeroProtocoloPublicidade = $_POST['nr_protocoloPublicidade'];
      $dataProtocoloPublicidade = $_POST['dt_protocoloPublicidade'];
      $linha = $_POST['ie_linha'];
        $crud = new crud('veiculo'); // instancia classe com as operaçoes crud, passando o nome da tabela como parametro
        $crud->atualizar("ie_servico='$servico',nr_prefixo='$prefixo',ie_fabricante='$fabricante'
				,ds_modelo='$modelo',ds_cor='$cor',dt_anoFabricacao='$anoFabricacao'
				,dt_anoModelo='$anoModelo',ds_chassi='$chassi',ds_placa='$placa'
				,ds_minicipioVeiculo='$municipioVeiculo',sg_ufVeiculo='$ufVeiculo'
        ,_publicidade='$publicidade',nr_qtdePassageiros='$qtdePassageiros',ds_associcao='$associcao',_particular='$particular'
        ,nr_protocoloPublicidade='$numeroProtocoloPublicidade',dt_protocoloPublicidade='$dataProtocoloPublicidade',ie_linha='$linha'", "id='$getId'"); // utiliza a funçao ATUALIZAR da classe crud
        header("Location: listagemAssociacao.php"); // redireciona para a listagem
    }

?>
	<!DOCTYPE html>
	<html lang="pt-br">

	<head>
<?php include 'include/head.php';?>


    <?php include 'include/header.php';?>

    <div id="page-container">
       
        <?php include 'include/menu.php';?>

<div id="page-content">
    <div id='wrap'>
        <div id="page-heading">
            <ol class="breadcrumb">
<!--                 <li class='active'><a href="index.php">Dashboad</a></li> -->
            </ol>
<!--             <h1>Dashboard</h1>             -->
        </div>       

       <div id="main" class="col-sm-3">
			<h3 class="page-header">Cadastro de Veiculos</h3>
		</div>

	

			<form action="" method="POST">

				<div class="row">
					<div class="form-group col-md-6">
						<label for="InputServico">Tipo de Serviço:</label>
            <select name="ie_servico" id="ie_servico" class="form-control" required >
	        <option value="<?php echo @$campo['ie_servico'];?>"><?php echo @$campo['ie_servico'];?></option>
              <option value="Lotação">Lotação</option>
         	<option value="Taxi">Taxi </option>
	        <option value="Escolar">Escolar</option>
              <option value="Caminhões de aluguel">Caminhões de aluguel</option>
	</select>
					</div>
				</div>


				<label>Prefixo:
      <input type="number" name="nr_prefixo" id="nr_prefixo" class="form-control"  maxlength="4"
               value="<?php echo @$campo['nr_prefixo'];?>" /></label>

				<label>Fabricante:
          <select name="ie_fabricante" id="ie_fabricante" class="form-control" required value="<?php echo @$campo['ie_fabricante'];?>">
	        <option value="">-</option>
            <option value="MARCOLOPO">MARCOLOPO</option>
         	<option value="OUTROS">OUTROS </option>
	        
	</select></label>

				<label>Modelo:
      <input name="ds_modelo" type="text" id="ds_modelo" class="form-control" required value="<?php echo @$campo['ds_modelo'];?>" /></label></br>

				<div class="row">
					<div class="form-group col-md-2">
						<label for="InputCor">Cor</label>
						<input type="text" id="ds_cor" name="ds_cor" class="form-control" required value="<?php echo @$campo['ds_cor'];?>" />
					</div>
					<div class="form-group col-md-4">


						<label for="InputAnoFabricacao">Ano Fabricação</label>
						<input type="text" id="dt_anoFabricacao" name="dt_anoFabricacao" class="form-control" maxlength="4" value="<?php echo @$campo['dt_anoFabricacao'];?>" />
					</div>
				</div>
				<div class="row">
					<div class="form-group col-md-2">
						<label>Ano Modelo:</label>
						<input type="text" id="dt_anoModelo" name="dt_anoModelo" class="form-control" required value="<?php echo @$campo['dt_anoModelo'];?>" />
					</div>
					<div class="form-group col-md-1">
						<label>Chassi:</label>
						<input type="text" id="ds_chassi" name="ds_chassi" class="form-control" required maxlength="4" value="<?php echo @$campo['ds_chassi'];?>" />
					</div>
				</div>

				<div class="row">
					<div class="form-group col-md-2">
						<label for="InputPlaca">Placa</label>
						<input type="text" id="ds_placa" name="ds_placa" class="form-control" maxlength="8"  required value="<?php echo @$campo['ds_placa'];?>" />
					</div>
					<div class="form-group col-md-4">
						<label for="InputMunicipio">Municipio do Veiculo</label>
						<input type="text" id="ds_minicipioVeiculo" name="ds_minicipioVeiculo" class="form-control"  required value="<?php echo @$campo['ds_minicipioVeiculo'];?>" />
					</div>
				</div>

				<div class="row">
					<div class="form-group col-md-2">
						<label for="InputUf">U.F</label>
            <select name="sg_ufVeiculo" id="sg_ufVeiculo" class="form-control" required value="<?php echo @$campo['sg_ufVeiculo'];?>">
	        <option value="<?php echo @$campo['sg_ufVeiculo'];?>"><?php echo @$campo['sg_ufVeiculo'];?></option>
            <option value="SP">SP</option>
         	<option value="RJ">RJ </option>
	        
	</select></label>
						
					</div>
      	<div class="form-group col-md-2">
				
            <input type="checkbox"  id="_particular" name="_particular" class="form-control" value="<?php echo @$campo['_particular'];?>" 
									 <?php if(@$campo['_particular']!=null){?> checked <?php ;};?> 
	>Particular
					
					</div>
				</div>
  
  <div class="row">
					<div class="form-group col-md-2">
						<label for="InputQtdePassageiros">Qtde. Passageiros</label>
            <input type="text" id="nr_qtdePassageiros" name="nr_qtdePassageiros" class="form-control"  required value="<?php echo @$campo['nr_qtdePassageiros'];?>" />
					
					</div>
					<div class="form-group col-md-4">
						<label for="InputAssociacao">Associcao:</label>
            <select name="ds_associcao" id="ds_associcao" class="form-control" required >
	        <option value="<?php echo @$campo['ds_associcao'];?>"><?php echo @$campo['ds_associcao'];?></option>
              <option value="...">...</option>
         
	</select>
					</div>
    <div class="form-group col-md-2">
				
            <input type="checkbox"  id="_publicidade" name="_publicidade" class="form-control" value="<?php echo @$campo['_publicidade'];?>"
									 <?php if(@$campo['_publicidade']!=null){?> checked <?php ;};?> 
									 >Permitido Publicidade
					
					</div>
				</div>
  <div class="row">
					<div class="form-group col-md-4">
						<label for="InputProtocolo">Numero do Protocolo Publicidade:
	       <input type="text" id="nr_protocoloPublicidade" name="nr_protocoloPublicidade" class="form-control"  required value="<?php echo @$campo['nr_protocoloPublicidade'];?>" /></label>
					</div>
    <div class="form-group col-md-4">
						<label for="InputProtocolo">Data do Protocolo Publicidade:
	       <input type="text" id="dt_protocoloPublicidade" name="dt_protocoloPublicidade" class="form-control"  maxlength="4" required value="<?php echo @$campo['dt_protocoloPublicidade'];?>" /></label>
					</div>
    <div class="form-group col-md-4">
						<label for="InputProtocolo">Linha:
	       <input type="text" id="ie_linha" name="ie_linha" class="form-control" required value="<?php echo @$campo['ie_linha'];?>" /></label>
					</div>
				</div>

				<?php
                if(@!$campo['id']){ // se nao passar o id via GET nao está editando, mostra o botao de cadastro
            ?>
					<input type="submit" name="cadastrar" class="btn btn-primary" value="Cadastrar" />
					<a href="listagemAssociacao.php" class="btn btn-default">Cancelar</a>
					<?php }else{ // se  passar o id via GET  está editando, mostra o botao de ediçao ?>
					<input type="submit" name="editar" class="btn btn-primary" value="Salvar" />
					<a href="listagemAssociacao.php" class="btn btn-default">Cancelar</a>
					<?php } ?>
			</form> <!-- container -->
    </div> <!--wrap -->
</div> <!-- page-content -->

    <?php include 'include/footer.php';?>

</div> <!-- page-container -->
<script type='text/javascript' src='assets/js/jquery-1.10.2.min.js'></script> 
<script type='text/javascript' src='assets/js/jqueryui-1.10.3.min.js'></script> 
<script type='text/javascript' src='assets/js/bootstrap.min.js'></script> 
<script type='text/javascript' src='assets/js/enquire.js'></script> 
<script type='text/javascript' src='assets/js/jquery.cookie.js'></script> 
<script type='text/javascript' src='assets/js/jquery.touchSwipe.min.js'></script> 
<script type='text/javascript' src='assets/js/jquery.nicescroll.min.js'></script> 
<script type='text/javascript' src='assets/plugins/codeprettifier/prettify.js'></script> 
<script type='text/javascript' src='assets/plugins/easypiechart/jquery.easypiechart.min.js'></script> 
<script type='text/javascript' src='assets/plugins/sparklines/jquery.sparklines.min.js'></script> 
<script type='text/javascript' src='assets/plugins/form-toggle/toggle.min.js'></script> 
<script type='text/javascript' src='assets/plugins/form-wysihtml5/wysihtml5-0.3.0.min.js'></script> 
<script type='text/javascript' src='assets/plugins/form-wysihtml5/bootstrap-wysihtml5.js'></script> 
<script type='text/javascript' src='assets/plugins/fullcalendar/fullcalendar.min.js'></script> 
<script type='text/javascript' src='assets/plugins/form-daterangepicker/daterangepicker.min.js'></script> 
<script type='text/javascript' src='assets/plugins/form-daterangepicker/moment.min.js'></script> 
<script type='text/javascript' src='assets/plugins/charts-flot/jquery.flot.min.js'></script> 
<script type='text/javascript' src='assets/plugins/charts-flot/jquery.flot.resize.min.js'></script> 
<script type='text/javascript' src='assets/plugins/charts-flot/jquery.flot.orderBars.min.js'></script> 
<script type='text/javascript' src='assets/demo/demo-index.js'></script> 
<script type='text/javascript' src='assets/js/placeholdr.js'></script> 
<script type='text/javascript' src='assets/js/application.js'></script> 
<script type='text/javascript' src='assets/demo/demo.js'></script> 

	</body>

	</html>